#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#define MAX_POSITION 80

// �������Լ�ʵ�֣�Ȼ���Ķ���������˼·
int main() {
    int velocity;
    char grid[MAX_POSITION + 1];

    printf("Input velocity: ");
    scanf("%d", &velocity);

    int position = 0;
    while(1) {
        system("cls");
        memset(grid, '-', MAX_POSITION);
        grid[position] = 'O';
        grid[MAX_POSITION] = '\0';
        printf("%s\n", grid);
        position += velocity;
        if(position >= MAX_POSITION) position = 0;
        usleep(300000);
    }
    return 0;
}
