#include <stdio.h>
#include <math.h>

typedef struct {
    float x;
    float y;
    float z;
    float r;
} Sphere;

typedef enum {
    INSIDE, INTERSECT, TANGENT, SEPARATED
} Position;

float calcDistance(Sphere a, Sphere b) {
	// fill your codes here
}

Position getPosition(Sphere a, Sphere b) {
	// fill your codes here
}

int main() {
    Sphere sphere1 = {0, 0, 0, 2};
    Sphere sphere2 = {3, 3, 3, 2};

    Position pos = getPosition(sphere1, sphere2);
    switch(pos) {
        case INSIDE:
            printf("Sphere1 is inside Sphere2.\n");
            break;
        case INTERSECT:
            printf("Sphere1 intersects with Sphere2.\n");
            break;
        case TANGENT:
            printf("Sphere1 is tangent to Sphere2.\n");
            break;
        case SEPARATED:
            printf("Sphere1 is separated from Sphere2.\n");
            break;
    }
    return 0;
}
