#include <stdio.h>
#include <stdlib.h>
#define BOARD_SIZE 19

int board[BOARD_SIZE][BOARD_SIZE];

void init_board() {
    // fill your codes here
}

void print_board() {
	// fill your codes here
}

int main() {
    init_board();
	print_board();
    return 0;
}
