#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <windows.h>

int main() {
    while(1) {
    	// fill your codes here: ����
		
        time_t rawtime;
        struct tm * timeinfo;
        time(&rawtime);
        timeinfo = localtime(&rawtime);
        printf("\rtime: %02d:%02d:%02d\n", timeinfo->tm_hour, timeinfo->tm_min, timeinfo->tm_sec);
        
		// fill your codes here: ����1����ӳ�
    }

    return 0;
}
