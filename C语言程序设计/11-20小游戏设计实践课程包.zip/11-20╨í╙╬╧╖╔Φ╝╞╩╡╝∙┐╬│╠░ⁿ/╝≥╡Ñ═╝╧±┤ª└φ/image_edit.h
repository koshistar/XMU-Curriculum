#include <stdio.h>
#define WIDTH 512
#define HEIGHT 512

// ��ȡPGMͼ�񵽶�ά����
void read_image(char* filename, unsigned char image[HEIGHT][WIDTH]) {
    FILE* file = fopen(filename, "rb");
    if (file == NULL) {
        printf("cannot open your file\n");
        return;
    }
    char buffer[16];
    unsigned int max_val;

    // ��ȡ"ͼ���ʽ"��Ӧ����"P5"��
    fgets(buffer, sizeof(buffer), file);
    if (buffer[0] != 'P' || buffer[1] != '5') {
        printf("wrong file format\n");
        return;
    }
    // ��ȡͼ��ߴ磨Ӧ����512x512��
    int width, height;
    fscanf(file, "%d %d", &width, &height);
    if (width != WIDTH || height != HEIGHT) {
        printf("wrong image size, shoule be 512 * 512\n");
        return;
    }
    // ��ȡ��������ֵ��Ӧ����255��
    fscanf(file, "%d", &max_val);
    if (max_val != 255) {
        printf("wrong max_val\n");
        return;
    }
    fgetc(file);
    fread(image, sizeof(unsigned char), WIDTH * HEIGHT, file);
    fclose(file);
}

// �����ά���鵽PGMͼ��
void save_image(char* filename, unsigned char image[HEIGHT][WIDTH]) {
    FILE* file = fopen(filename, "wb");
    if (file == NULL) {
        printf("cannot open your file\n");
        return;
    }
    fprintf(file, "P5\n");
    fprintf(file, "%d %d\n", WIDTH, HEIGHT);
    fprintf(file, "255\n");
    fwrite(image, sizeof(unsigned char), WIDTH * HEIGHT, file);
    fclose(file);
}
