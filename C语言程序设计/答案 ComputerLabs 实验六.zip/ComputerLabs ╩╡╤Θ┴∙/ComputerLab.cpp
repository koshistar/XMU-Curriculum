#include"ComputerLab.h"

void ComputerLab::display()
{
	int i, j;
	for (i = 1; i <= 4; i++)
	{
		cout << i << ' ';
		for (j = 1; j <= 6; j++)
		{
			if (i == 1 && j > 5 || i == 3 && j > 4 || i == 4 && j > 3) break;
			cout << j << ':' << lab[i][j].name << ' ';
		}
		cout << endl;
	}
}

void ComputerLab::operator +(loginReq& r)
{
	string is_empty = "empty";
	int i, j;
	r.flag = true;
	if (lab[r.labNum][r.stationNum].name != is_empty)
	{
		r.flag = false;
	}
	else
	{
		for (i = 1; i <= 4; i++)
		{
			for (j = 1; j <= 6; j++)
			{
				if (i == 1 && j > 5 || i == 3 && j > 4 || i == 4 && j > 3) break;
				if (lab[i][j].name == r.userPointer->id)
				{
					r.flag = false;
					break;
				}
			}
			if (r.flag == 0) break;
		}
	}
	if (r.flag == false) cout << "invalid login" << endl;
	else  lab[r.labNum][r.stationNum].name = r.userPointer->id;
	display();
}
void ComputerLab::operator -(logoffReq& r)
{
	string is_empty = "empty";
	int i, j;
	r.flag = false;
	for (i = 1; i <= 4; i++)
	{
		for (j = 1; j <= 6; j++)
		{
			if (i == 1 && j > 5 || i == 3 && j > 4 || i == 4 && j > 3) break;
			if (lab[i][j].name == r.userPointer->id)
			{
				r.flag = true;
				lab[i][j].name = is_empty;
				break;
			}
		}
		if (r.flag == true) break;
	}
	if (r.flag == false) cout << "invalid logoff" << endl;
	display();
}
void User::setid(string s)
{
	id = s;
}
