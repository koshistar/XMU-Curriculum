﻿#include <iostream>
#include<string>
#include"ComputerLab.h"
using namespace std;

int main()
{
	ComputerLab computerlab;
	char operation;
	loginReq login;
	logoffReq logoff;
	string s;
	while (operation=getchar())
	{
		getchar();//吸收操作符后面的空格
		if (operation == '=') break;
		else if (operation == '+')
		{
			login.userPointer = new User;
			cin >> s;
			login.userPointer->setid(s);
			cin >> login.labNum >> login.stationNum;
			getchar();//吸收回车符
			computerlab + login;
		}
		else if (operation == '-')
		{
			logoff.userPointer = new User;
			cin >> s;
			logoff.userPointer->setid(s);
			getchar();//吸收回车符
			computerlab - logoff;
		}
	}
	return 0;
}