package math;

public class mathcompute {

	/**
	 * @param args
	 */
	public int add(int x,int y){
		System.out.println(x+"+"+y+"="+(x+y));
		return x+y;
	}
	public int sub(int x,int y){
		System.out.println(x+"-"+y+"="+(x-y));
		return x-y;
	}
	public int mul(int x,int y){
		System.out.println(x+"*"+y+"="+(x*y));
		return x*y;
	}
	public int div(int x,int y){
		try{
			System.out.println(x+"/"+y+"="+(x/y));
			return x/y;
		}catch(Exception e){
			System.out.println(e);
			return -99999999;
		}		
	}
	
	
	public static void main(String[] args) {
		mathcompute mc=new mathcompute();
		int x1,y1,x2,y2,x3,y3,x4,y4;
		x1=3;y1=2;
		x2=5;y2=4;
		x3=8;y3=2;
		x4=10;y4=0;
		mc.add(x1,y1);
		mc.add(x2, y2);
		mc.add(x3, y3);
		mc.add(x4, y4);
		mc.sub(x1,y1);
		mc.sub(x2, y2);
		mc.sub(x3, y3);
		mc.sub(x4, y4);
		mc.mul(x1,y1);
		mc.mul(x2, y2);
		mc.mul(x3, y3);
		mc.mul(x4, y4);
		mc.div(x1,y1);
		mc.div(x2, y2);
		mc.div(x3, y3);
		mc.div(x4, y4);
		

	}

}
