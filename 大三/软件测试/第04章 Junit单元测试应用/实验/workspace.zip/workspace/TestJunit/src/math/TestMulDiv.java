package math;

import junit.framework.TestCase;

public class TestMulDiv extends TestCase {
	private mathcompute mc;
	private int x1,y1,r11,r12,x2,y2,r21,r22,x3,y3,r31,r32,x4,y4,r41,r42;

	protected void setUp() throws Exception {
		super.setUp();
		mc=new mathcompute();
		x1=3;y1=2;r11=6;r12=1;
		x2=5;y2=4;r21=20;r22=1;
		x3=8;y3=2;r31=16;r32=4;
		x4=10;y4=0;r41=0;r42=-99999999;
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testMul() {
		assertEquals(r11,mc.mul(x1, y1));
		assertEquals(r21,mc.mul(x2, y2));
		assertEquals(r31,mc.mul(x3, y3));
		assertEquals(r41,mc.mul(x4, y4));
	}

	public void testDiv() {
		assertEquals(r12,mc.div(x1, y1));
		assertEquals(r22,mc.div(x2, y2));
		assertEquals(r32,mc.div(x3, y3));
		assertEquals(r42,mc.div(x4, y4));
	}

}
