package helloworld;

import junit.framework.TestCase;

public class sayhelloTest extends TestCase {
	private sayhello sh;
	private int x1,x2,x3;

	protected void setUp() throws Exception {
		super.setUp();
		sh=new sayhello();
		x1=3;
		x2=6;
		x3=-1;
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testPrintx() {
		assertEquals(1,sh.printx(x1));
		assertEquals(0,sh.printx(x2));
		assertEquals(-1,sh.printx(x3));
	}

}
