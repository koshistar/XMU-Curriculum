package math;

import junit.framework.TestCase;

public class TestAddSub extends TestCase {
	private mathcompute mc;
	private int x1,y1,r11,r12,x2,y2,r21,r22,x3,y3,r31,r32,x4,y4,r41,r42;
	

	protected void setUp() throws Exception {
		super.setUp();
		mc=new mathcompute();
		x1=3;y1=2;r11=5;r12=1;
		x2=5;y2=4;r21=9;r22=1;
		x3=8;y3=2;r31=10;r32=6;
		x4=10;y4=0;r41=10;r42=10;
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testAdd() {
		assertEquals(r11,mc.add(x1, y1));
		assertEquals(r21,mc.add(x2, y2));
		assertEquals(r31,mc.add(x3, y3));
		assertEquals(r41,mc.add(x4, y4));
	}

	public void testSub() {
		assertEquals(r12,mc.sub(x1, y1));
		assertEquals(r22,mc.sub(x2, y2));
		assertEquals(r32,mc.sub(x3, y3));
		assertEquals(r42,mc.sub(x4, y4));
	}

}
