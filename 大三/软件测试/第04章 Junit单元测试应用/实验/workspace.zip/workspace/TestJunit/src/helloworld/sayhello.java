package helloworld;

public class sayhello {

	/**
	 * @param args
	 */
	public int printx(int x){
		if(x<0){
			System.out.println(x+"�Ǹ���");
			return -1;
		}
		if(x%2==0){
			System.out.println(x+"��ż��");
			return 0;
		}
		else{
			System.out.println(x+"������");
			return 1;
		}
	}
	public static void main(String[] args) {
		int x1,x2,x3;
		sayhello sh=new sayhello();
		x1=3;
		x2=6;
		x3=-1;
		sh.printx(x1);
		sh.printx(x2);
		sh.printx(x3);

	}

}
