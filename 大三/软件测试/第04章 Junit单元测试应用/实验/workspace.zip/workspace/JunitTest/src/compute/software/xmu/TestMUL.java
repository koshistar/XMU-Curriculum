package compute.software.xmu;

import junit.framework.TestCase;

public class TestMUL extends TestCase {
	private compute c;
	private int x1,y1,r1,x2,y2,r2,x3,y3,r3,x4,y4,r4;

	protected void setUp() throws Exception {
		super.setUp();
		c=new compute();
		x1=3;y1=3;r1=9;
		x2=8;y2=5;r2=40;
		x3=10;y3=0;r3=0;
		x4=-8;y4=7;r4=-56;
		
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testMUL() {
		assertEquals(r1,c.MUL(x1, y1));
		assertEquals(r2,c.MUL(x2, y2));
		assertEquals(r3,c.MUL(x3, y3));
		assertEquals(r4,c.MUL(x4, y4));
	}

}
