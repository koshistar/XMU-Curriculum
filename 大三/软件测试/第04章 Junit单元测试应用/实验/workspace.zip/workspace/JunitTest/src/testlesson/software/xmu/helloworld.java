package testlesson.software.xmu;

public class helloworld {

	/**
	 * @param args
	 */
	
	public int printx(int x){
		if(x<0) return -1;
		if(x%2==0) {
			System.out.println(x+"��ż��");
			return 0;
		}
		else{
			System.out.println(x+"������");
			return 1;
		}
	}
	public static void main(String[] args) {
		helloworld hw=new helloworld();
		int x1, x2;
		x1=6;
		x2=3;
		hw.printx(x1);
		hw.printx(x2);
		
		

	}

}
