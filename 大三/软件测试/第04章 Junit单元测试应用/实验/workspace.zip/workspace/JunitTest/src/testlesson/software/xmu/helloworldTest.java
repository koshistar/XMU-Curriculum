package testlesson.software.xmu;

import junit.framework.TestCase;

public class helloworldTest extends TestCase {
	/*������Թ̼�*/
	private helloworld hw;
	private int x1,x2,x3,x4;

	protected void setUp() throws Exception {
		super.setUp();
		/*��ʼ��*/
		hw=new helloworld();
		x1=4;
		x2=5;
		x3=-3;
		x4=0;
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testPrintx() {
		assertEquals(0,hw.printx(x1));
		assertEquals(1,hw.printx(x2));
		assertEquals(1,hw.printx(x3));
		assertEquals(0,hw.printx(x4));
	}

}
