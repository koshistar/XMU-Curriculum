package compute.software.xmu;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTests {

	public static Test suite() {
		TestSuite suite = new TestSuite(AllTests.class.getName());
		//$JUnit-BEGIN$
		suite.addTestSuite(TestMUL.class);
		suite.addTestSuite(TestDiv.class);
		//$JUnit-END$
		return suite;
	}

}
