package compute.software.xmu;

public class compute {

	/**
	 * @param args
	 */
	public int MUL(int x,int y){
		System.out.println(x+"����"+y+"="+x*y);
		return x*y;
	}
	
	public int Div(int x, int y){
		try{
			System.out.println(x+"����"+y+"="+x/y);
			return x/y;
		}catch(Exception e){
			System.out.println(e);
			return -1;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		compute c=new compute();
		int x1,x2,y1,y2;
		x1=5;y1=3;
		x2=10;y2=0;
		
		c.MUL(x1, y1);
		c.MUL(x2, y2);
		c.Div(x1, y1);
		c.Div(x2, y2);

	}

}
