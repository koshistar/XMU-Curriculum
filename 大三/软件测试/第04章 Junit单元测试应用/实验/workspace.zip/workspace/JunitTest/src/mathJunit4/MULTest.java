 package mathJunit4;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.Ignore;

public class MULTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testMultiple() {
		assertEquals(6,Math.multiple(2, 3));
	}
	
	@Ignore("�����������")
	@Test
	public void printx(){
		System.out.println("û��ִ��");
	}

}
