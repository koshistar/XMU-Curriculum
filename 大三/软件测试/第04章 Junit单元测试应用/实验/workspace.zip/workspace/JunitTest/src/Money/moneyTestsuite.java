package Money;

import junit.framework.Test;
import junit.framework.TestSuite;

public class moneyTestsuite {

	public static Test suite() {
		TestSuite suite = new TestSuite("Test for money.junit.testlesson");
		//$JUnit-BEGIN$
		suite.addTestSuite(MoneyBagTest.class);
		//$JUnit-END$
		return suite;
	}

}
