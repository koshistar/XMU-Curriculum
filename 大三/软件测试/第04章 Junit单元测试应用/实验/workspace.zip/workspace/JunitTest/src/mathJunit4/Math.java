package mathJunit4;

public class Math {
	 public static int divide(int x,int y) {   
	        return x/y;   
	    }   
	  
	    public static int multiple(int x,int y) {   
	        return x*y;   
	    }   
}
