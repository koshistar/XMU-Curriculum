#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

// ������ʹ�������У�
// gcc -o 06-����-�ı��༭��.exe 06-����-�ı��༭��.c -mwindows -lcomdlg32 -lgdi32 -luser32

#define ID_FILE_SAVE 2
#define ID_QUIT 3

void save_str(char* filename, char* txt);

LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
    static HWND hwndEdit;

    switch(msg)
    {
        case WM_CREATE:
		{
		    hwndEdit = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "", WS_CHILD | WS_VISIBLE | 
		                              WS_VSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL, 
		                              0, 0, 100, 100, hwnd, (HMENU) 1, NULL, NULL);
		    // ��������������
			HFONT hFont = CreateFont(21, 0, 0, 0, FW_NORMAL, FALSE, 
				FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, \
				DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Consolas"
			);
			SendMessage(hwndEdit, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(TRUE, 0));
			
		    HMENU hMenu, hSubMenu;
		    hMenu = CreateMenu();
		    hSubMenu = CreatePopupMenu();
		    AppendMenu(hSubMenu, MF_STRING, ID_FILE_SAVE, "&����");
		    AppendMenu(hSubMenu, MF_STRING, ID_QUIT, "&�˳�");
		    
		    MENUITEMINFO menuItemInfo = {0};
		    menuItemInfo.cbSize = sizeof(MENUITEMINFO);
		    menuItemInfo.fMask = MIIM_SUBMENU | MIIM_STRING;
		    menuItemInfo.hSubMenu = hSubMenu;
		    menuItemInfo.dwTypeData = "&�ļ�";
		    
		    InsertMenuItem(hMenu, 0, TRUE, &menuItemInfo);
		    SetMenu(hwnd, hMenu);
		}
		break;

        case WM_SIZE:
        {
            RECT rcClient;
            GetClientRect(hwnd, &rcClient);
            SetWindowPos(hwndEdit, NULL, 0, 0, rcClient.right, rcClient.bottom, SWP_NOZORDER);
        }
        break;

        case WM_COMMAND:
            switch(wp)
            {
                case ID_FILE_SAVE:
                {
                    OPENFILENAME ofn;
                    char szFileName[MAX_PATH] = "";
                    ZeroMemory(&ofn, sizeof(ofn));
                    ofn.lStructSize = sizeof(ofn);
                    ofn.hwndOwner = hwnd;
                    ofn.lpstrFilter = "Text Files (*.txt)\0*.txt\0All Files (*.*)\0*.*\0";
                    ofn.lpstrFile = szFileName;
                    ofn.nMaxFile = MAX_PATH;
                    ofn.Flags = OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
                    ofn.lpstrDefExt = "txt";
                    if(GetSaveFileName(&ofn))
                    {
                        int len = GetWindowTextLength(hwndEdit);
                        char* content = (char*)malloc((len + 1) * sizeof(char));
                        GetWindowText(hwndEdit, content, len + 1);
                        save_str(szFileName, content);
                        free(content);
                    }
                }
                case ID_QUIT:
                {
					DestroyWindow(hwnd);
				}
                break;
            }
        break;

        case WM_CLOSE:
            DestroyWindow(hwnd);
        break;
        
        case WM_DESTROY:
            PostQuitMessage(0);
        break;

        default:
            return DefWindowProc(hwnd, msg, wp, lp);
    }

    return 0;
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR args, int ncmdshow)
{
    WNDCLASSA wc = {0};

    wc.hbrBackground = (HBRUSH)COLOR_WINDOW;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hInstance = hInst;
    wc.lpszClassName = "txtEditer";
    wc.lpfnWndProc = WindowProcedure; 

    if(!RegisterClassA(&wc))
        return -1;

    CreateWindowExA(
        0,
        "txtEditer", 
        "NotePad", 
        WS_OVERLAPPEDWINDOW | WS_VISIBLE,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
        NULL,
        NULL,
        hInst,
        NULL
    );

    MSG msg = {0};

    while(GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}

void save_str(char* filename, char* txt) {
    wchar_t wfilename[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, filename, -1, wfilename, MAX_PATH);

    wchar_t* wtxt = (wchar_t*)malloc((strlen(txt) + 1) * sizeof(wchar_t));
    MultiByteToWideChar(CP_ACP, 0, txt, -1, wtxt, strlen(txt) + 1);

    FILE* file = _wfopen(wfilename, L"w, ccs=UTF-16LE");
    if (file == NULL) {
        printf("Failed to open file: %s\n", filename);
        return;
    }

    fputws(wtxt, file);
    fclose(file);
    free(wtxt);
}
