#include <windows.h>
#include <commctrl.h>

#define BUTTON_ID 101
#define LABEL_ID 102
#define EDIT_ID 103
#define LISTBOX_ID 104
#define COMBOBOX_ID 105
#define CHECKBOX_ID 106
#define RADIOBUTTON1_ID 107
#define RADIOBUTTON2_ID 108
#define SCROLLBAR_ID 109
#define PROGRESS_ID 110
#define SLIDER_ID 111

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
		INITCOMMONCONTROLSEX iccex;
		iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
		iccex.dwICC  = ICC_PROGRESS_CLASS | ICC_BAR_CLASSES;
		InitCommonControlsEx(&iccex);
        
		case WM_CREATE:
        {
			// �༭��
			HWND hwndEdit = CreateWindow("edit", "",
				WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE,
				15, 15, 400, 100,
				hwnd, (HMENU)EDIT_ID, NULL, NULL
			);
		}
		{
			// �б���
			HWND hwndList = CreateWindow("listbox", "",
				WS_CHILD | WS_VISIBLE | LBS_STANDARD,
				15, 130, 400, 100,
				hwnd, (HMENU)LISTBOX_ID, NULL, NULL
			);
			
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM)"��Ŀ1");
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM)"��Ŀ2");
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM)"��Ŀ3");	
		}
        {
			// ��Ͽ�
			HWND hwndCombo = CreateWindow("combobox", "",
			    WS_CHILD | WS_VISIBLE | CBS_DROPDOWN,
			    15, 225, 400, 100,
				// ע�⣬�߶����õ��������б������߶ȣ�����combobox��ʵ�ʸ߶�
			    hwnd, (HMENU)COMBOBOX_ID, NULL, NULL
			);
			
			// ����Ͽ�����ѡ��
			SendMessage(hwndCombo, CB_ADDSTRING, 0, (LPARAM)"ѡ��1");
			SendMessage(hwndCombo, CB_ADDSTRING, 0, (LPARAM)"ѡ��2");
			SendMessage(hwndCombo, CB_ADDSTRING, 0, (LPARAM)"ѡ��3");
			
			// ����Ĭ��ѡ����
			SendMessage(hwndCombo, CB_SETCURSEL, 0, 0);				
		}
		{
			// ��ѡ��
			HWND hwndCheck = CreateWindow("button", "��ѡ��",
			    WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
			    15, 265, 400, 30,
			    hwnd, (HMENU)CHECKBOX_ID, NULL, NULL
			);
		}
		{
			// ��ѡ��ť
			HWND hwndRadio1 = CreateWindow("button", "ѡ��1",
			    WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
			    15, 310, 120, 30,
			    hwnd, (HMENU)RADIOBUTTON1_ID, NULL, NULL
			);
			HWND hwndRadio2 = CreateWindow("button", "ѡ��2",
			    WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
			    180, 310, 120, 30,
			    hwnd, (HMENU)RADIOBUTTON2_ID, NULL, NULL
			);		
		}
		{
			// ������
			HWND hwndScroll = CreateWindow("scrollbar", "",
			    WS_CHILD | WS_VISIBLE | SBS_HORZ,
			    15, 355, 400, 30,
			    hwnd, (HMENU)SCROLLBAR_ID, NULL, NULL);			
		}
		{
			// ����������ҪCommCtrl��֧�֣�
			HWND hwndProgress = CreateWindow(PROGRESS_CLASS, "",
			    WS_CHILD | WS_VISIBLE, 
				15, 400, 400, 30,
			    hwnd, (HMENU)PROGRESS_ID, NULL, NULL
			);
			
			int newPosition = 50; // �����µĽ�����λ�ã���ΧΪ0��100��
			SendMessage(hwndProgress, PBM_SETPOS, newPosition, 0);
		}
		{	
			// ����ؼ�����ҪCommCtrl��֧�֣�
			HWND hwndSlider = CreateWindow(TRACKBAR_CLASS, "",
			    WS_CHILD | WS_VISIBLE | TBS_AUTOTICKS,
			    15, 445, 400, 30, 
				hwnd, (HMENU)SLIDER_ID, NULL, NULL
			);
			
			// ���û������Сֵ�����ֵ
			int minValue = 0; // ������Сֵ
			int maxValue = 100; // �������ֵ
			SendMessage(hwndSlider, TBM_SETRANGEMIN, TRUE, minValue);
			SendMessage(hwndSlider, TBM_SETRANGEMAX, TRUE, maxValue);
			
			// ���û���Ŀ̶�Ƶ��
			int tickFrequency = 5; // ���ÿ̶�Ƶ��
			SendMessage(hwndSlider, TBM_SETTICFREQ, tickFrequency, 0);
		}
            break;

        case WM_CLOSE:
            DestroyWindow(hwnd);
            break;

        case WM_DESTROY:
            PostQuitMessage(0);
            break;

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    const char CLASS_NAME[] = "Sample Window Class";

    WNDCLASS wc = { };

    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;

    RegisterClass(&wc);
    
    RECT rect;
	rect.left = 0;
	rect.top = 0;
	rect.right = 430;
	rect.bottom = 530;
	AdjustWindowRect(&rect, WS_OVERLAPPEDWINDOW, FALSE);

    HWND hwnd = CreateWindowEx(0, CLASS_NAME, "�ؼ���ʾ",
                    WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 
					rect.right - rect.left, 
					rect.bottom - rect.top,
                    NULL, NULL, hInstance, NULL
				);

    if (hwnd == NULL) {
        return 0;
    }

    ShowWindow(hwnd, nCmdShow);

    // Message loop.
    MSG msg = { };
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}
