#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

// �ؼ��ı�ʶ��
#define BUTTON_ID 1
#define LABEL_ID 2
int counter = 0;

char* intToString(int num) {
    char *to_str = calloc(256, sizeof(char));
    sprintf(to_str, "%d", num);
    return to_str;
}

// ���ڹ���
LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    static HWND hwndButton;
    static HWND hwndLabel;
    switch (msg)
    {
    case WM_CREATE:
        hwndButton = CreateWindow("button", "Add",
                                  WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                                  20, 20, 120, 40,
                                  hwnd, (HMENU)BUTTON_ID, NULL, NULL);
        hwndLabel = CreateWindow("static", "0",
                                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                                 20, 80, 200, 30,
                                 hwnd, (HMENU)LABEL_ID, NULL, NULL);
        break;
    case WM_COMMAND:
        if (LOWORD(wParam) == BUTTON_ID)
        {
            counter++;
            SetWindowText(hwndLabel, intToString(counter));
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR args, int ncmdshow)
{
    const char CLASS_NAME[] = "Sample Window Class";

    WNDCLASS wc = {0};

    wc.lpfnWndProc = WindowProcedure;
    wc.hInstance = hInst;
    wc.lpszClassName = CLASS_NAME;

    if (!RegisterClass(&wc))
    {
        MessageBox(NULL, "Window Registration Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    HWND hwnd = CreateWindowEx(
        0,
        CLASS_NAME,
        "Learn to Program Windows",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 280, 180, // �������ڴ�С
        NULL,
        NULL,
        hInst,
        NULL
        );

    if (hwnd == NULL)
    {
        MessageBox(NULL, "Window Creation Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    ShowWindow(hwnd, ncmdshow);
    UpdateWindow(hwnd);

    MSG msg = {0};
    while (GetMessage(&msg, NULL, 0, 0) > 0)
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}
