#include <windows.h>

#define CELL_SIZE 30

LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        COLORREF color1 = RGB(212, 169, 75);
        COLORREF color2 = RGB(232, 216, 167);
		
        for (int i = 0; i < 18; i++) {
            for (int j = 0; j < 18; j++) {
                // ȷ����Ԫ���λ��
                RECT cellRect = { i * CELL_SIZE, j * CELL_SIZE, (i + 1) * CELL_SIZE, (j + 1) * CELL_SIZE };

                // ѡ����ɫ
                HBRUSH hBrush;
                if ((i + j) % 2 == 0) {
                    hBrush = CreateSolidBrush(color1);
                }
                else {
                    hBrush = CreateSolidBrush(color2);
                }

                // ������Ԫ��
                FillRect(hdc, &cellRect, hBrush);

                // ɾ����ˢ
                DeleteObject(hBrush);
            }
        }

        EndPaint(hwnd, &ps);
        break;
    }
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

// ������
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR args, int ncmdshow)
{
    const char CLASS_NAME[] = "Sample Window Class";

    WNDCLASS wc = {0};

    wc.lpfnWndProc = WindowProcedure;
    wc.hInstance = hInst;
    wc.lpszClassName = CLASS_NAME;

    if (!RegisterClass(&wc))
    {
        MessageBox(NULL, "����ע��ʧ��!", "����!", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    // ���㴰�ڵĴ�С����Ӧ���̣����ǵ����ڱ߿�ͱ�����
    RECT rect = { 0, 0, 18 * CELL_SIZE, 18 * CELL_SIZE };
    AdjustWindowRect(&rect, WS_OVERLAPPEDWINDOW, FALSE);

    HWND hwnd = CreateWindowEx(
        0,
        CLASS_NAME,
        "Χ������",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 
		rect.right - rect.left, rect.bottom - rect.top,
        NULL,
        NULL,
        hInst,
        NULL
    );

    if (hwnd == NULL)
    {
        MessageBox(NULL, "���ڴ���ʧ��!", "����!", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    ShowWindow(hwnd, ncmdshow);
    UpdateWindow(hwnd);

    MSG msg = {0};
    while (GetMessage(&msg, NULL, 0, 0) > 0)
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}
