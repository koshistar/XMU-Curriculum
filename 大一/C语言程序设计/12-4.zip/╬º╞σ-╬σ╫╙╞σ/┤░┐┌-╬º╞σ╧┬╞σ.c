#include <windows.h>

#define CELL_SIZE 30
#define RADIUS 14
#define BOARD_SIZE 19
#define BORDER_SIZE CELL_SIZE

int board[BOARD_SIZE][BOARD_SIZE] = {0};

void place_piece(int x, int y)
{
    if (x >= 0 && x < BOARD_SIZE && y >= 0 && y < BOARD_SIZE) {
        board[x][y] = 1;
    }
}

void draw_cell(HDC hdc, int i, int j, COLORREF color1, COLORREF color2)
{
    HBRUSH hBrush;
    RECT cellRect = { BORDER_SIZE + i * CELL_SIZE, BORDER_SIZE + j * CELL_SIZE, 
                      BORDER_SIZE + (i + 1) * CELL_SIZE, BORDER_SIZE + (j + 1) * CELL_SIZE };

    if ((i + j) % 2 == 0)
    {
        hBrush = CreateSolidBrush(color1);
    }
    else
    {
        hBrush = CreateSolidBrush(color2);
    }

    FillRect(hdc, &cellRect, hBrush);
    DeleteObject(hBrush);
}

void draw_piece(HDC hdc, int i, int j)
{
    if (board[i][j] == 1)
    {
        HBRUSH hBrushPiece = CreateSolidBrush(RGB(255, 255, 255));
        HBRUSH hOldBrush = (HBRUSH)SelectObject(hdc, hBrushPiece);

        Ellipse(hdc, BORDER_SIZE + i * CELL_SIZE - RADIUS, BORDER_SIZE + j * CELL_SIZE - RADIUS,
                BORDER_SIZE + i * CELL_SIZE + RADIUS, BORDER_SIZE + j * CELL_SIZE + RADIUS);

        SelectObject(hdc, hOldBrush);
        DeleteObject(hBrushPiece);
    }
}

void handle_click(HWND hwnd, LPARAM lParam)
{
    const int offset = CELL_SIZE / 2;
    int xPos = LOWORD(lParam) - BORDER_SIZE;
    int yPos = HIWORD(lParam) - BORDER_SIZE;

    int x = (xPos + offset) / CELL_SIZE;
    int y = (yPos + offset) / CELL_SIZE;

    place_piece(x, y);
    // ��֮ǰ���Ƶ�������Ч������һ��msg����WM_PAINT
    InvalidateRect(hwnd, NULL, TRUE);
}

LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        COLORREF color1 = RGB(212, 169, 75);    // ��ɫ
        COLORREF color2 = RGB(232, 216, 167);  // ��ɫ

        for (int i = 0; i < BOARD_SIZE - 1; i++)
        {
            for (int j = 0; j < BOARD_SIZE - 1; j++)
            {
                draw_cell(hdc, i, j, color1, color2);
            }
        }
        
        for (int i = 0; i < BOARD_SIZE; i++)
		{
		    for (int j = 0; j < BOARD_SIZE; j++)
		    {
		        draw_piece(hdc, i, j);
		    }
		}

        EndPaint(hwnd, &ps);
        break;
    }
    case WM_LBUTTONDOWN:
        handle_click(hwnd, lParam);
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }

    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    const char CLASS_NAME[] = "Sample Window Class";

    WNDCLASS wc = { };

    wc.lpfnWndProc = WindowProcedure;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;

    if (!RegisterClass(&wc))
    {
        MessageBox(NULL, "Window Registration Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    RECT rect;
	rect.left = 0;
	rect.top = 0;
	rect.right = (BOARD_SIZE + 1) * CELL_SIZE;
	rect.bottom = (BOARD_SIZE + 1) * CELL_SIZE;
	
	AdjustWindowRect(&rect, WS_OVERLAPPEDWINDOW, FALSE);
	
	HWND hwnd = CreateWindowEx(
	    0,
	    CLASS_NAME,
	    "Our First Window",
	    WS_OVERLAPPEDWINDOW,
	    CW_USEDEFAULT, CW_USEDEFAULT, 
	    rect.right - rect.left, 
	    rect.bottom - rect.top,
	    NULL,
	    NULL,
	    hInstance,
	    NULL
	);

    // Set the window background color
    HBRUSH hBrush = CreateSolidBrush(RGB(242, 226, 177)); // White
    SetClassLongPtr(hwnd, GCLP_HBRBACKGROUND, (LONG_PTR)hBrush);

    if (hwnd == NULL)
    {
        MessageBox(NULL, "Window Creation Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG msg = { };
    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}
