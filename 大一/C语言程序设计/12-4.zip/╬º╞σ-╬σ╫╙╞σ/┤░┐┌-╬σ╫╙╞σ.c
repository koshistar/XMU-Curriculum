#include <windows.h>
#include <stdio.h>

#define CELL_SIZE 30
#define RADIUS 14
#define BOARD_SIZE 15
#define BORDER_SIZE CELL_SIZE
#define SIZE 5

// �������Ҫ�����д��ڣ�gcc -o ����-������.exe ����-������.c -mwindows

int player = 0;
int board[BOARD_SIZE][BOARD_SIZE] = {0};

int checkWinner(int board[BOARD_SIZE][BOARD_SIZE]) {
    int dx[4] = {1, 1, 0, -1};
    int dy[4] = {0, 1, 1, 1};
    for (int i = 0; i < BOARD_SIZE; ++i) {
        for (int j = 0; j < BOARD_SIZE; ++j) {
            if (board[i][j] == 0) continue;
            for (int dir = 0; dir < 4; ++dir) {
                int x = i, y = j;
                for (int k = 0; k < SIZE; ++k) {
                    if (x < 0 || x >= BOARD_SIZE || y < 0 || y >= BOARD_SIZE || board[x][y] != board[i][j])
                        break;
                    if (k == SIZE - 1)
                        return board[i][j];
                    x += dx[dir];
                    y += dy[dir];
                }
            }
        }
    }
    return 0;
}

void reset_board() {
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            board[i][j] = 0;
        }
    }
}

void place_piece(int x, int y, HWND hwnd)
{
    if (x >= 0 && x < BOARD_SIZE && y >= 0 && y < BOARD_SIZE) {
        board[x][y] = player + 1;
    }
}

void draw_cell(HDC hdc, int i, int j, COLORREF color1, COLORREF color2)
{
    HBRUSH hBrush;
    RECT cellRect = { BORDER_SIZE + i * CELL_SIZE, BORDER_SIZE + j * CELL_SIZE, 
                      BORDER_SIZE + (i + 1) * CELL_SIZE, BORDER_SIZE + (j + 1) * CELL_SIZE };

    if ((i + j) % 2 == 0) {
        hBrush = CreateSolidBrush(color1);
    }
    else {
        hBrush = CreateSolidBrush(color2);
    }

    FillRect(hdc, &cellRect, hBrush);
    DeleteObject(hBrush);
}

void draw_piece(HDC hdc, int i, int j)
{
    if (board[i][j] != 0)
    {
        int c = board[i][j] - 1 ? 0 : 255;
        HBRUSH hBrushPiece = CreateSolidBrush(RGB(c, c, c));
        HBRUSH hOldBrush = (HBRUSH)SelectObject(hdc, hBrushPiece);

        HPEN hPen = CreatePen(PS_NULL, 0, RGB(0, 0, 0));
        HPEN hOldPen = (HPEN)SelectObject(hdc, hPen);

        Ellipse(hdc, BORDER_SIZE + i * CELL_SIZE - RADIUS, BORDER_SIZE + j * CELL_SIZE - RADIUS,
                BORDER_SIZE + i * CELL_SIZE + RADIUS, BORDER_SIZE + j * CELL_SIZE + RADIUS);

        SelectObject(hdc, hOldPen);
        DeleteObject(hPen);

        SelectObject(hdc, hOldBrush);
        DeleteObject(hBrushPiece);
    }
}

void handle_click(HWND hwnd, LPARAM lParam)
{
    const int offset = CELL_SIZE / 2;
    int xPos = LOWORD(lParam) - BORDER_SIZE;
    int yPos = HIWORD(lParam) - BORDER_SIZE;

    int x = min((xPos + offset) / CELL_SIZE, BOARD_SIZE - 1);
	int y = min((yPos + offset) / CELL_SIZE, BOARD_SIZE - 1);
	
	if(board[x][y] == 0){
		player = (player + 1) % 2;
		place_piece(x, y, hwnd);
	}
	
    InvalidateRect(hwnd, NULL, TRUE);

    int winner = checkWinner(board);
    if (winner != 0) {
        const char* message = winner == 1 ? "�����ʤ!" : "�����ʤ!";
        MessageBox(
            hwnd,
            message,
            "��Ϸ����",
            MB_OK
        );
        reset_board();
        InvalidateRect(hwnd, NULL, TRUE);
    }
}

LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
    {
    case WM_PAINT:
	{
	    PAINTSTRUCT ps;
	    HDC hdc = BeginPaint(hwnd, &ps);
	    COLORREF color1 = RGB(212, 169, 75);
	    COLORREF color2 = RGB(232, 216, 167);
	
	    for (int i = 0; i < BOARD_SIZE - 1; i++) {
	        for (int j = 0; j < BOARD_SIZE - 1; j++) {
	            draw_cell(hdc, i, j, color1, color2);
	        }
	    }
		
	    for (int i = 0; i < BOARD_SIZE; i++) {
	        for (int j = 0; j < BOARD_SIZE; j++) {
	            draw_piece(hdc, i, j);
	        }
	    }
	
	    EndPaint(hwnd, &ps);
	    break;
	}
    case WM_LBUTTONDOWN:
        handle_click(hwnd, lParam);
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }

    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    const char CLASS_NAME[] = "cheese";

    WNDCLASS wc = { };

    wc.lpfnWndProc = WindowProcedure;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;

    if (!RegisterClass(&wc))
    {
        MessageBox(NULL, "Window Registration Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    RECT rect;
	rect.left = 0;
	rect.top = 0;
	rect.right = (BOARD_SIZE + 1) * CELL_SIZE;
	rect.bottom = (BOARD_SIZE + 1) * CELL_SIZE;
	
	AdjustWindowRect(&rect, WS_OVERLAPPEDWINDOW, FALSE);
	
	HWND hwnd = CreateWindowEx(
	    0,
	    CLASS_NAME,
	    "������С��Ϸ",
	    WS_OVERLAPPEDWINDOW,
	    CW_USEDEFAULT, CW_USEDEFAULT, 
	    rect.right - rect.left, 
	    rect.bottom - rect.top,
	    NULL,
	    NULL,
	    hInstance,
	    NULL
	);

    // Set the window background color
    HBRUSH hBrush = CreateSolidBrush(RGB(242, 226, 177));
    SetClassLongPtr(hwnd, GCLP_HBRBACKGROUND, (LONG_PTR)hBrush);

    if (hwnd == NULL)
    {
        MessageBox(NULL, "Window Creation Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG msg = { };
    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}
